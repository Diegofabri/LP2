﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace P30481723041
{
    public partial class frmProva : Form
    {
        public frmProva()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double[,] vendas = new double[1, 4];
            double totalMes = 0.0;
            double totalGeral = 0.0;
            int i, j;

            for (i = 0; i < 1; i++)
            {
                for (j = 0; j < 4; j++)
                {
                    if (!double.TryParse(Interaction.InputBox("Informe as vendas: (Mês " + (i + 1) + " / Semana " + (j + 1) + ")"), out vendas[i, j]))
                    {
                        MessageBox.Show("Valor inválido.");
                        j--;
                    }
                    else
                    {
                        totalMes += vendas[i, j];
                        lstResultado.Items.Add("Total do mês: " + (i + 1) + " Semana: " + (j + 1) + " " + (vendas[i, j].ToString("C")));
                    }
                }
                lstResultado.Items.Add("\nTotal do Mês " + (i + 1) + ": " + (totalMes.ToString("C")));
            }
            totalGeral = totalMes;
            lstResultado.Items.Add("\n>>Total Geral: " + (totalGeral.ToString("C")));
        }
    }
}
